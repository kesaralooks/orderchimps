import React from "react";
import { DetailsCard } from "../../components/DetailsCard";
import { FeaturedRestaurant } from "../../components/FeaturedRestaurant";
import { FlashDealCard } from "../../components/FlashDealCard";
import { FooterMenuItems } from "../../components/FooterMenuItems";
import { OcLogoNew } from "../../components/OcLogoNew";
import { OurTopCitiesMenu } from "../../components/OurTopCitiesMenu";
import { SearchByFoodItems } from "../../components/SearchByFoodItems";
import { ServiceElements } from "../../components/ServiceElements";
import { StoreGooglePlay } from "../../components/StoreGooglePlay";
import { AppStoreDownloadButton } from "../../icons/AppStoreDownloadButton";
import "./style.css";

export const Index = () => {
  return (
    <div className="index">
      <div className="top-nav-header">
        <div className="overlap">
          <div className="rectangle" />
          <div className="rectangle-2" />
          <img
            className="rectangle-3"
            alt="Rectangle"
            src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-20.png"
          />
          <div className="header">
            <div className="overlap-2">
              <img
                className="group-2"
                alt="Group"
                src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/group-1-1.png"
              />
              <div className="overlap-wrapper">
                <div className="overlap-3">
                  <div className="shadow">
                    <div className="overlap-group-2">
                      <div className="ellipse" />
                      <div className="ellipse-2" />
                    </div>
                  </div>
                  <img
                    className="image-base"
                    alt="Image base"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-base@2x.png"
                  />
                  <img
                    className="overlay"
                    alt="Overlay"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/overlay@2x.png"
                  />
                </div>
              </div>
              <div className="title-order-card">
                <div className="title-3">
                  <div className="text-wrapper-6">Are you starving?</div>
                  <p className="text-wrapper-7">Within a few clicks, find meals that are accessible near you</p>
                </div>
                <div className="order-card">
                  <div className="top">
                    <div className="tab">
                      <div className="icon-3">motorcycle</div>
                      <div className="text-6">Delivery</div>
                    </div>
                    <div className="tab-2">
                      <div className="icon-4">shopping-bag</div>
                      <div className="text-7">Pickup</div>
                    </div>
                  </div>
                  <img
                    className="HR"
                    alt="Hr"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hr.svg"
                  />
                  <div className="bottom">
                    <div className="text-field-button">
                      <div className="text-field">
                        <div className="icon-5">map-marker-alt</div>
                        <div className="text-8">Enter Your Address</div>
                      </div>
                      <div className="button-2">
                        <div className="icon-6">SEARCH</div>
                        <div className="text-9">Find Food</div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="top-nav">
            <div className="logo">
              <OcLogoNew className="oc-logo-new-1-variant2" />
            </div>
            <div className="deliver-address">
              <div className="text-wrapper-8">Deliver to:</div>
              <div className="frame-2">
                <div className="text-wrapper-9">map-marker-alt</div>
                <div className="div-2">
                  <div className="text-wrapper-10">Current Location</div>
                  <div className="text-wrapper-11">Beauchamp Court, Barnet</div>
                </div>
              </div>
            </div>
            <div className="search-login-button">
              <div className="frame-3">
                <div className="text-wrapper-12">Search</div>
                <div className="text-wrapper-13">Search Food</div>
              </div>
              <div className="frame-4">
                <div className="text-wrapper-14">user</div>
                <div className="text-wrapper-15">Login</div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="div-3">
        <FlashDealCard className="design-component-instance-node" text="15" />
        <FlashDealCard
          className="design-component-instance-node"
          image="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-1.png"
          text="10"
        />
        <FlashDealCard
          className="design-component-instance-node"
          image="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-2.png"
          text="25"
          text1="7 Days Remaining"
        />
        <FlashDealCard
          className="design-component-instance-node"
          image="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-3.png"
          text="20"
          text1="8 Days Remaining"
        />
      </div>
      <div className="how-does-it-work">
        <div className="title-4">How does it work</div>
        <div className="features">
          <ServiceElements
            className="design-component-instance-node"
            donut="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/donut-1@2x.png"
            donutClassName="frame-5"
            hasInvoice={false}
            hasMenu={false}
            mapMarker="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/map-marker-1@2x.png"
            menuClassName="service-elements-instance"
            titleClassName="frame-6"
          />
          <ServiceElements
            className="design-component-instance-node"
            group="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/group-1@2x.png"
            hasDonut={false}
            hasInvoice={false}
            hasMapMarker={false}
            text="Choose order"
            text1="Check over hundreds of menus to pick your favorite food"
            titleClassName="frame-6"
          />
          <ServiceElements
            className="design-component-instance-node"
            hasDonut={false}
            hasMapMarker={false}
            hasMenuWrapper={false}
            invoice="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/invoice-1@2x.png"
            invoiceClassName="frame-7"
            text="Pay advanced"
            text1="It&#39;s quick, safe, and simple. Select several methods of payment"
            titleClassName="frame-6"
          />
          <ServiceElements
            className="design-component-instance-node"
            donut="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/donut-2@2x.png"
            donutClassName="frame-8"
            hasInvoice={false}
            hasMapMarker={false}
            hasMenuWrapper={false}
            text="Enjoy meals"
            text1="Food is made and delivered directly to your home."
            titleClassName="frame-6"
          />
        </div>
      </div>
      <div className="popular-items">
        <div className="overlap-4">
          <div className="title-cards">
            <div className="title-5">Popular items</div>
            <div className="cards">
              <div className="element-5">
                <div className="image-title">
                  <div className="rectangle-wrapper">
                    <img
                      className="rectangle-4"
                      alt="Rectangle"
                      src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-336.png"
                    />
                  </div>
                  <div className="name-location-price">
                    <div className="name-location">
                      <div className="name-3">Cheese Burger</div>
                      <div className="location">
                        <div className="icon-7">map-marker-alt</div>
                        <div className="text-10">Burger Arena</div>
                      </div>
                    </div>
                    <div className="div-4">
                      <div className="text-wrapper-16">$3.88</div>
                    </div>
                  </div>
                </div>
                <button className="div-wrapper">
                  <div className="text-9">Order Now</div>
                </button>
              </div>
              <div className="element-5">
                <div className="image-title">
                  <div className="rectangle-wrapper">
                    <img
                      className="rectangle-4"
                      alt="Rectangle"
                      src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-336-1.png"
                    />
                  </div>
                  <div className="name-location-price">
                    <div className="name-location">
                      <div className="name-3">Toffe’s Cake</div>
                      <div className="location">
                        <div className="icon-7">map-marker-alt</div>
                        <div className="text-10">Top Sticks</div>
                      </div>
                    </div>
                    <div className="div-4">
                      <div className="text-wrapper-16">$4.00</div>
                    </div>
                  </div>
                </div>
                <button className="div-wrapper">
                  <div className="text-9">Order Now</div>
                </button>
              </div>
              <div className="element-5">
                <div className="image-title">
                  <div className="rectangle-wrapper">
                    <img
                      className="rectangle-4"
                      alt="Rectangle"
                      src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-336-2.png"
                    />
                  </div>
                  <div className="name-location-price">
                    <div className="name-location">
                      <div className="name-3">Dancake</div>
                      <div className="location">
                        <div className="icon-7">map-marker-alt</div>
                        <div className="text-10">Cake World</div>
                      </div>
                    </div>
                    <div className="div-4">
                      <div className="text-wrapper-16">$1.99</div>
                    </div>
                  </div>
                </div>
                <button className="div-wrapper">
                  <div className="text-9">Order Now</div>
                </button>
              </div>
              <div className="element-5">
                <div className="image-title">
                  <div className="rectangle-wrapper">
                    <img
                      className="rectangle-4"
                      alt="Rectangle"
                      src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-336-3.png"
                    />
                  </div>
                  <div className="name-location-price">
                    <div className="name-location">
                      <div className="name-3">Crispy Sandwitch</div>
                      <div className="location">
                        <div className="icon-7">map-marker-alt</div>
                        <div className="text-10">Fastfood Dine</div>
                      </div>
                    </div>
                    <div className="div-4">
                      <div className="text-wrapper-16">$3.00</div>
                    </div>
                  </div>
                </div>
                <button className="div-wrapper">
                  <div className="text-9">Order Now</div>
                </button>
              </div>
              <div className="element-5">
                <div className="image-title">
                  <div className="rectangle-wrapper">
                    <img
                      className="rectangle-4"
                      alt="Rectangle"
                      src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/rectangle-336-4.png"
                    />
                  </div>
                  <div className="name-location-price">
                    <div className="name-location">
                      <div className="name-3">Thai&nbsp;&nbsp;Soup</div>
                      <div className="location">
                        <div className="icon-7">map-marker-alt</div>
                        <div className="text-10">Foody man</div>
                      </div>
                    </div>
                    <div className="div-4">
                      <div className="text-wrapper-16">$2.79</div>
                    </div>
                  </div>
                </div>
                <button className="div-wrapper">
                  <div className="text-9">Order Now</div>
                </button>
              </div>
            </div>
          </div>
          <div className="slider-button">
            <div className="icon-wrapper">
              <div className="icon-8">chevron-left</div>
            </div>
            <div className="icon-wrapper">
              <div className="icon-8">chevron-right</div>
            </div>
          </div>
        </div>
      </div>
      <div className="featured-restaurant-2">
        <div className="title-6">Featured Restaurants</div>
        <div className="cards-2">
          <div className="div-3">
            <FeaturedRestaurant
              badgeProperty1="opens-tomorrow"
              className="design-component-instance-node"
              overlapGroupClassName="featured-restaurant-card"
            />
            <FeaturedRestaurant
              badgeProperty1="opens-tomorrow"
              className="design-component-instance-node"
              overlapGroupClassName="featured-restaurant-instance"
              restaruantLogoProperty1="one"
              text="15% off"
              text1="Pizzahub"
              text2="40"
            />
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="featured-restaurant-card-instance"
              restaruantLogoProperty1="six"
              text="10% off"
              text1="Donuts hut"
              text2="20"
            />
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="element-6"
              restaruantLogoProperty1="seven"
              text="15% off"
              text1="Donuts hut"
              text2="50"
            />
          </div>
          <div className="div-3">
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="element-7"
              restaruantLogoProperty1="four"
              text="10% off"
              text1="Ruby Tuesday"
              text2="26"
            />
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="element-8"
              restaruantLogoProperty1="five"
              text="25% off"
              text1="Kuakata Fried Chicken"
              text2="53"
            />
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="element-9"
              restaruantLogoProperty1="two"
              text="10% off"
              text1="Red Square"
              text2="45"
            />
            <FeaturedRestaurant
              badgeProperty1="open-now"
              className="design-component-instance-node"
              overlapGroupClassName="element-10"
              restaruantLogoProperty1="three"
              text="10% off"
              text1="Taco Bell"
              text2="35"
            />
          </div>
        </div>
        <div className="button-3">
          <div className="text-9">View All</div>
          <div className="icon-6">CHEVRON-RIGHT</div>
        </div>
      </div>
      <div className="search-by-food">
        <div className="title-items-button-wrapper">
          <div className="title-items-button">
            <div className="div-5">
              <div className="title-6">Search by Food</div>
              <div className="buttons">
                <div className="button-4">
                  <div className="text-wrapper-17">View All</div>
                  <div className="icon-9">CHEVRON-RIGHT</div>
                </div>
                <div className="div-3">
                  <div className="arrow-left">
                    <div className="icon-8">chevron-left</div>
                  </div>
                  <div className="arrow-right">
                    <div className="icon-8">chevron-right</div>
                  </div>
                </div>
              </div>
            </div>
            <div className="div-5">
              <SearchByFoodItems
                className="design-component-instance-node"
                nameClassName="search-by-food-items-instance"
              />
              <SearchByFoodItems
                className="design-component-instance-node"
                foodPhotoClassName="element-11"
                nameClassName="search-by-food-items-instance"
                text="Burger"
              />
              <SearchByFoodItems
                className="design-component-instance-node"
                foodPhotoClassName="element-12"
                nameClassName="search-by-food-items-instance"
                text="Noodles"
              />
              <SearchByFoodItems
                className="design-component-instance-node"
                foodPhotoClassName="element-13"
                nameClassName="search-by-food-items-instance"
                text="Sub-sandiwch"
              />
              <SearchByFoodItems
                className="design-component-instance-node"
                foodPhotoClassName="element-14"
                nameClassName="search-by-food-items-instance"
                text="Chowmein"
              />
              <SearchByFoodItems
                className="design-component-instance-node"
                foodPhotoClassName="element-15"
                nameClassName="search-by-food-items-instance"
                text="Steak"
              />
            </div>
          </div>
        </div>
        <div className="card-wrapper">
          <div className="card">
            <div className="element-16">
              <img
                className="icon-10"
                alt="Icon"
                src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/icon.svg"
              />
              <div className="text-11">
                Daily
                <br />
                Discounts
              </div>
            </div>
            <img
              className="HR-2"
              alt="Hr"
              src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hr-1.svg"
            />
            <div className="element-16">
              <div className="icon-10">
                <div className="overlap-group-3">
                  <img
                    className="vector"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/vector.svg"
                  />
                  <img
                    className="vector-2"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/vector-1.svg"
                  />
                  <img
                    className="vector-3"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/vector-2.svg"
                  />
                  <div className="ellipse-3" />
                  <img
                    className="vector-4"
                    alt="Vector"
                    src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/vector-3.svg"
                  />
                </div>
              </div>
              <div className="text-11">
                Live
                <br />
                Tracing
              </div>
            </div>
            <img
              className="HR-2"
              alt="Hr"
              src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hr-1.svg"
            />
            <div className="element-16">
              <img
                className="icon-10"
                alt="Icon"
                src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/icon-1.svg"
              />
              <div className="text-11">
                Quick
                <br />
                Delivery
              </div>
            </div>
          </div>
        </div>
        <div className="app-download">
          <div className="overlap-5">
            <div className="background" />
            <div className="text-button">
              <div className="text-12">
                <div className="title-7">Install the app</div>
                <p className="body-4">
                  It&#39;s never been easier to order food. Look for the finest discounts and you&#39;ll be lost in a
                  world of delectable food.
                </p>
              </div>
              <div className="div-4">
                <StoreGooglePlay
                  className="google-play-download"
                  getItOn="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/get-it-on-1.svg"
                  getItOnClassName="store-google-play-instance"
                  googlePlay="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/google-play-1.svg"
                  googlePlayClassName="store-google-play-style-outline"
                  googlePlayLogoClassName="store-google-play-style-outline-instance"
                />
                <AppStoreDownloadButton className="app-store-download" />
              </div>
            </div>
            <div className="image-2">
              <div className="overlap-6">
                <div className="light-iphone-w">
                  <div className="overlap-7">
                    <div className="i-phone">
                      <div className="overlap-group-4">
                        <img
                          className="hardware-buttons"
                          alt="Hardware buttons"
                          src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hardware-buttons@2x.png"
                        />
                        <img
                          className="subtract"
                          alt="Subtract"
                          src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/subtract-2.svg"
                        />
                        <div className="mask-group-wrapper">
                          <img
                            className="mask-group"
                            alt="Mask group"
                            src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/mask-group.png"
                          />
                        </div>
                        <img
                          className="union"
                          alt="Union"
                          src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/union.svg"
                        />
                        <div className="speaker-camera">
                          <div className="rectangle-5" />
                          <div className="ellipse-4" />
                        </div>
                      </div>
                    </div>
                    <div className="rectangle-6" />
                  </div>
                </div>
                <div className="i-phone-wrapper">
                  <div className="i-phone-2">
                    <div className="overlap-group-5">
                      <div className="iphone-shape" />
                      <img
                        className="hardware-buttons-2"
                        alt="Hardware buttons"
                        src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hardware-buttons-1@2x.png"
                      />
                      <img
                        className="subtract-2"
                        alt="Subtract"
                        src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/subtract-3.svg"
                      />
                      <img
                        className="mask-group-2"
                        alt="Mask group"
                        src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/mask-group-1.png"
                      />
                      <img
                        className="union-2"
                        alt="Union"
                        src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/union-1.svg"
                      />
                      <div className="speaker-camera-2">
                        <div className="rectangle-7" />
                        <div className="ellipse-5" />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="details">
        <DetailsCard className="design-component-instance-node" property1="details-card-left" />
        <DetailsCard
          bodyClassName="details-card-3"
          className="design-component-instance-node"
          image="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-17.png"
          property1="details-card-right"
          spanClassName="details-card-2"
          spanClassNameOverride="details-card-2"
          text={
            <>
              Celebrate&nbsp;&nbsp;parties
              <br />
              with{" "}
            </>
          }
          text1="Fried Chicken"
          text2={
            <>
              Get the best fried chicken smeared with a lip smacking lemon chili flavor. Check out <br />
              best deals for fried chicken.
            </>
          }
          titleClassName="details-card-instance"
        />
        <DetailsCard
          bodyClassNameOverride="details-card-3"
          className="details-card-6"
          img="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-18.png"
          leftClassName="details-card-4"
          property1="details-card-left"
          spanClassName1="details-card-5"
          spanClassName2="details-card-2"
          text={
            <>
              Wanna eat hot <br />
              &amp; spicy{" "}
            </>
          }
          text1="Pizza?"
          text2={
            <>
              Pair up with a friend and enjoy the <br />
              hot and crispy pizza pops. Try it <br />
              with the best deals.
            </>
          }
          titleClassNameOverride="details-card-instance"
        />
      </div>
      <div className="CTA-footer">
        <div className="CTA">
          <div className="text-button-2">
            <p className="text-13">Are you ready to order with the best deals?</p>
            <div className="button-5">
              <div className="text-14">PROCEED TO ORDER</div>
              <div className="icon-11">CHEVRON-RIGHT</div>
            </div>
          </div>
        </div>
        <footer className="footer">
          <div className="our-top-cities">
            <div className="title-8">Our top cities</div>
            <div className="div-5">
              <OurTopCitiesMenu className="design-component-instance-node" />
              <OurTopCitiesMenu
                className="design-component-instance-node"
                divClassName="our-top-cities-menu-items-1"
                divClassNameOverride="our-top-cities-menu-items-1"
                elementClassName="our-top-cities-menu-items-1"
                elementClassName1="our-top-cities-menu-items-1"
                elementClassNameOverride="our-top-cities-menu-items-1"
                text="Los Angeles"
                text1="Washington DC"
                text2="Seattle"
                text3="Portland"
                text4="Nashville"
              />
              <OurTopCitiesMenu
                className="design-component-instance-node"
                divClassName="our-top-cities-menu-items-1"
                divClassNameOverride="our-top-cities-menu-items-1"
                elementClassName="our-top-cities-menu-items-1"
                elementClassName1="our-top-cities-menu-items-1"
                elementClassNameOverride="our-top-cities-menu-items-1"
                text="New York City"
                text1="Orange County"
                text2="Atlanta"
                text3="Charlotte"
                text4="Denver"
              />
              <OurTopCitiesMenu
                className="design-component-instance-node"
                divClassName="our-top-cities-menu-items-1"
                divClassNameOverride="our-top-cities-menu-items-1"
                elementClassName="our-top-cities-menu-items-1"
                elementClassName1="our-top-cities-menu-items-1"
                elementClassNameOverride="our-top-cities-menu-items-1"
                text="Chicago"
                text1="Phoenix"
                text2="Las Vegas"
                text3="Sacramento"
                text4="Oklahoma City"
              />
              <OurTopCitiesMenu
                className="design-component-instance-node"
                divClassName="our-top-cities-menu-items-1"
                divClassNameOverride="our-top-cities-menu-items-1"
                elementClassName="our-top-cities-menu-items-1"
                elementClassName1="our-top-cities-menu-items-1"
                elementClassNameOverride="our-top-cities-menu-items-1"
                text="Columbus"
                text1="New Mexico"
                text2="Albuquerque"
                text3="Sacramento"
                text4="New Orleans"
              />
            </div>
          </div>
          <div className="menu-subscription">
            <img
              className="HR-3"
              alt="Hr"
              src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hr-3.svg"
            />
            <div className="div-5">
              <div className="menu-2">
                <FooterMenuItems className="design-component-instance-node" />
                <FooterMenuItems
                  className="design-component-instance-node"
                  hasElement={false}
                  text="Contact"
                  text1="Help &amp; Support"
                  text2="Partner with us"
                  text3="Ride with us"
                />
                <FooterMenuItems
                  className="design-component-instance-node"
                  text="Legal"
                  text1="Terms &amp; Conditions"
                  text2="Refund &amp; Cancellation"
                  text3="Privacy Policy"
                  text4="Cookie Policy"
                />
              </div>
              <div className="follow-subscription">
                <div className="follow-us">
                  <div className="title-9">FOLLOW US</div>
                  <div className="icons-2">
                    <div className="element-17"></div>
                    <div className="element-17"></div>
                    <div className="element-17"></div>
                  </div>
                </div>
                <div className="subscription">
                  <p className="text-15">Receive exclusive offers in your mailbox</p>
                  <div className="text-field-button">
                    <div className="text-field-2">
                      <div className="text-wrapper-18">envelope</div>
                      <div className="text-16">Enter Your email</div>
                    </div>
                    <button className="button-6">
                      <div className="text-wrapper-19">Subscribe</div>
                    </button>
                  </div>
                </div>
              </div>
            </div>
            <div className="HR-rights">
              <img
                className="HR-3"
                alt="Hr"
                src="https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/hr-3.svg"
              />
              <div className="div-5">
                <div className="r-ights">
                  <div className="copyright">
                    <div className="text-wrapper-20">All rights Reserved</div>
                    <div className="symbol">copyright</div>
                  </div>
                  <div className="div-4">
                    <div className="text-wrapper-21">orderchimps.com, 2023</div>
                  </div>
                </div>
                <div className="made-by">
                  <div className="text-wrapper-20">Developed and hosted by</div>
                  <div className="div-2">
                    <div className="text-wrapper-21">OrderChimps</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </footer>
      </div>
    </div>
  );
};
