import { OurTopCitiesMenu } from ".";

export default {
  title: "Components/OurTopCitiesMenu",
  component: OurTopCitiesMenu,
};

export const Default = {
  args: {
    className: {},
    elementClassName: {},
    text: "San Francisco",
    elementClassNameOverride: {},
    text1: "Miami",
    divClassName: {},
    text2: "San Diego",
    divClassNameOverride: {},
    text3: "East Bay",
    elementClassName1: {},
    text4: "Long Beach",
  },
};
