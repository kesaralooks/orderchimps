import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const OurTopCitiesMenu = ({
  className,
  elementClassName,
  text = "San Francisco",
  elementClassNameOverride,
  text1 = "Miami",
  divClassName,
  text2 = "San Diego",
  divClassNameOverride,
  text3 = "East Bay",
  elementClassName1,
  text4 = "Long Beach",
}) => {
  return (
    <div className={`our-top-cities-menu ${className}`}>
      <div className={`element ${elementClassName}`}>{text}</div>
      <div className={`element-2 ${elementClassNameOverride}`}>{text1}</div>
      <div className={`element-2 ${divClassName}`}>{text2}</div>
      <div className={`element-2 ${divClassNameOverride}`}>{text3}</div>
      <div className={`element-2 ${elementClassName1}`}>{text4}</div>
    </div>
  );
};

OurTopCitiesMenu.propTypes = {
  text: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
  text3: PropTypes.string,
  text4: PropTypes.string,
};
