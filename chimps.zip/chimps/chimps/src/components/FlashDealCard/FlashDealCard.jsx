import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const FlashDealCard = ({
  className,
  text = "20",
  image = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-21.png",
  text1 = "6 Days Remaining",
}) => {
  return (
    <div className={`flash-deal-card ${className}`}>
      <div className="food-photo">
        <div className="overlap-group">
          <img className="image" alt="Image" src={image} />
          <div className="discount">
            <div className="number">{text}</div>
            <div className="percentage-symbol">
              <div className="text-wrapper">%</div>
              <div className="div">Off</div>
            </div>
          </div>
        </div>
      </div>
      <div className="texts-badge">
        <div className="text-wrapper-2">Greys Vage</div>
        <div className="frame">
          <div className="element-days-remaining">{text1}</div>
        </div>
      </div>
    </div>
  );
};

FlashDealCard.propTypes = {
  text: PropTypes.string,
  image: PropTypes.string,
  text1: PropTypes.string,
};
