import { FlashDealCard } from ".";

export default {
  title: "Components/FlashDealCard",
  component: FlashDealCard,
};

export const Default = {
  args: {
    className: {},
    text: "20",
    image:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image-21.png",
    text1: "6 Days Remaining",
  },
};
