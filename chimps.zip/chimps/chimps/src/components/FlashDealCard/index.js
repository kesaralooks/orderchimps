export { FlashDealCard } from "./FlashDealCard";
