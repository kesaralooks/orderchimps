import PropTypes from "prop-types";
import React from "react";
import { Badge } from "../Badge";
import { RestaruantLogo } from "../RestaruantLogo";
import "./style.css";

export const FeaturedRestaurant = ({
  className,
  overlapGroupClassName,
  badgeProperty1 = "open-now",
  text = "20% off",
  restaruantLogoProperty1 = "eight",
  text1 = "Foodworld",
  text2 = "46",
}) => {
  return (
    <div className={`featured-restaurant ${className}`}>
      <div className="overlap-group-wrapper">
        <div className={`badge-wrapper ${overlapGroupClassName}`}>
          <div className="badge-2">
            <div className="discount-2">
              <div className="icon">tag</div>
              <div className="text-2">{text}</div>
            </div>
            <div className="fast">
              <div className="icon">clock</div>
              <div className="text-2">Fast</div>
            </div>
          </div>
        </div>
      </div>
      <div className="image-name-review">
        <div className="image-name-review-2">
          <RestaruantLogo className="restaruant-logo-instance" property1={restaruantLogoProperty1} />
          <div className="name-review">
            <div className="name">{text1}</div>
            <div className="review">
              <div className="icon-2">Star</div>
              <div className="text-3">{text2}</div>
            </div>
          </div>
        </div>
        <Badge className="badge-instance" property1={badgeProperty1} />
      </div>
    </div>
  );
};

FeaturedRestaurant.propTypes = {
  badgeProperty1: PropTypes.string,
  text: PropTypes.string,
  restaruantLogoProperty1: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
};
