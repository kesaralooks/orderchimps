import { FeaturedRestaurant } from ".";

export default {
  title: "Components/FeaturedRestaurant",
  component: FeaturedRestaurant,
};

export const Default = {
  args: {
    className: {},
    overlapGroupClassName: {},
    badgeProperty1: "open-now",
    text: "20% off",
    restaruantLogoProperty1: "eight",
    text1: "Foodworld",
    text2: "46",
  },
};
