import { StoreGooglePlay } from ".";

export default {
  title: "Components/StoreGooglePlay",
  component: StoreGooglePlay,
};

export const Default = {
  args: {
    className: {},
    googlePlayClassName: {},
    googlePlay:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/google-play.svg",
    getItOnClassName: {},
    getItOn:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/get-it-on.svg",
    googlePlayLogoClassName: {},
  },
};
