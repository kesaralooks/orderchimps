import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const StoreGooglePlay = ({
  className,
  googlePlayClassName,
  googlePlay = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/google-play.svg",
  getItOnClassName,
  getItOn = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/get-it-on.svg",
  googlePlayLogoClassName,
}) => {
  return (
    <div className={`store-google-play ${className}`}>
      <img className={`google-play ${googlePlayClassName}`} alt="Google play" src={googlePlay} />
      <img className={`get-it-on ${getItOnClassName}`} alt="Get it on" src={getItOn} />
      <div className={`google-play-logo ${googlePlayLogoClassName}`} />
    </div>
  );
};

StoreGooglePlay.propTypes = {
  googlePlay: PropTypes.string,
  getItOn: PropTypes.string,
};
