import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const RestaruantLogo = ({ property1, className }) => {
  return <div className={`restaruant-logo ${property1} ${className}`} />;
};

RestaruantLogo.propTypes = {
  property1: PropTypes.oneOf(["seven", "two", "three", "four", "one", "five", "eight", "six"]),
};
