import { RestaruantLogo } from ".";

export default {
  title: "Components/RestaruantLogo",
  component: RestaruantLogo,
  argTypes: {
    property1: {
      options: ["seven", "two", "three", "four", "one", "five", "eight", "six"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "seven",
    className: {},
  },
};
