export { DetailsCard } from "./DetailsCard";
