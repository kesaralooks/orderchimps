import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const DetailsCard = ({
  property1,
  className,
  image = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image.png",
  titleClassName,
  spanClassName,
  text = "Best deals ",
  spanClassNameOverride,
  text1 = "Crispy Sandwiches",
  bodyClassName,
  text2 = "Enjoy the large size of sandwiches. Complete <br/>perfect slice of sandwiches.",
  leftClassName,
  titleClassNameOverride,
  spanClassName1,
  spanClassName2,
  bodyClassNameOverride,
  img = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image.png",
}) => {
  return (
    <div className={`details-card ${className}`}>
      <div className={`left ${property1} ${leftClassName}`}>
        {property1 === "details-card-left" && (
          <>
            <div className="text-4">
              <p className={`p ${titleClassNameOverride}`}>
                <span className={`span ${spanClassName1}`}>{text}</span>
                <span className={`text-wrapper-3 ${spanClassName2}`}>{text1}</span>
              </p>
              <p className={`body-2 ${bodyClassNameOverride}`}>{text2}</p>
            </div>
            <div className="button">
              <div className="proceed-to-order">PROCEED TO ORDER</div>
              <div className="text-wrapper-4">CHEVRON-RIGHT</div>
            </div>
          </>
        )}

        {property1 === "details-card-right" && <img className="img" alt="Image" src={image} />}
      </div>
      <div className={`right property-1-${property1}`}>
        {property1 === "details-card-left" && <img className="img" alt="Image" src={img} />}

        {property1 === "details-card-right" && (
          <>
            <div className="text-4">
              <p className={`p ${titleClassName}`}>
                <span className={`text-wrapper-5 ${spanClassName}`}>{text}</span>
                <span className={`text-wrapper-3 ${spanClassNameOverride}`}>{text1}</span>
              </p>
              <p className={`body-3 ${bodyClassName}`}>{text2}</p>
            </div>
            <div className="button">
              <div className="text-5">Proceed to order</div>
              <div className="text-wrapper-4">CHEVRON-RIGHT</div>
            </div>
          </>
        )}
      </div>
    </div>
  );
};

DetailsCard.propTypes = {
  property1: PropTypes.oneOf(["details-card-right", "details-card-left"]),
  image: PropTypes.string,
  text: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
  img: PropTypes.string,
};
