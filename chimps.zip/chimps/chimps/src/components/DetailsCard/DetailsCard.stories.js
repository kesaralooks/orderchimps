import { DetailsCard } from ".";

export default {
  title: "Components/DetailsCard",
  component: DetailsCard,
  argTypes: {
    property1: {
      options: ["details-card-right", "details-card-left"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "details-card-right",
    className: {},
    image: "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image.png",
    titleClassName: {},
    spanClassName: {},
    text: "Best deals ",
    spanClassNameOverride: {},
    text1: "Crispy Sandwiches",
    bodyClassName: {},
    text2: "Enjoy the large size of sandwiches. Complete <br/>perfect slice of sandwiches.",
    leftClassName: {},
    titleClassNameOverride: {},
    spanClassName1: {},
    spanClassName2: {},
    bodyClassNameOverride: {},
    img: "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/image.png",
  },
};
