import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const SearchByFoodItems = ({ className, nameClassName, foodPhotoClassName, text = "Pizza" }) => {
  return (
    <div className={`search-by-food-items ${className}`}>
      <div className={`food-photo-2 ${foodPhotoClassName}`} />
      <div className={`name-2 ${nameClassName}`}>{text}</div>
    </div>
  );
};

SearchByFoodItems.propTypes = {
  text: PropTypes.string,
};
