import { SearchByFoodItems } from ".";

export default {
  title: "Components/SearchByFoodItems",
  component: SearchByFoodItems,
};

export const Default = {
  args: {
    className: {},
    nameClassName: {},
    foodPhotoClassName: {},
    text: "Pizza",
  },
};
