import { ServiceElements } from ".";

export default {
  title: "Components/ServiceElements",
  component: ServiceElements,
};

export const Default = {
  args: {
    className: {},
    menuClassName: {},
    hasMenu: true,
    mapMarker:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/map-marker@2x.png",
    hasInvoice: true,
    donutClassName: {},
    donut:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/donut@2x.png",
    titleClassName: {},
    group:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/group@2x.png",
    hasMapMarker: true,
    hasDonut: true,
    text: "Select location",
    text1: "Choose the location where your food will be delivered.",
    hasMenuWrapper: true,
    invoiceClassName: {},
    invoice:
      "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/invoice@2x.png",
  },
};
