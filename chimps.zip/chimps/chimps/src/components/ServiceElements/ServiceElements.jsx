import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const ServiceElements = ({
  className,
  menuClassName,
  hasMenu = true,
  mapMarker = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/map-marker@2x.png",
  hasInvoice = true,
  donutClassName,
  donut = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/donut@2x.png",
  titleClassName,
  group = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/group@2x.png",
  hasMapMarker = true,
  hasDonut = true,
  text = "Select location",
  text1 = "Choose the location where your food will be delivered.",
  hasMenuWrapper = true,
  invoiceClassName,
  invoice = "https://cdn.animaapp.com/projects/655c6219ec0d332ecbfb07c4/releases/655c637cd798c187d3164aa7/img/invoice@2x.png",
}) => {
  return (
    <div className={`service-elements ${className}`}>
      <div className="icons">
        {hasMenuWrapper && (
          <div className={`menu ${menuClassName}`}>
            {hasMenu && (
              <div className="group-wrapper">
                <img className="group" alt="Group" src={group} />
              </div>
            )}
          </div>
        )}

        {hasMapMarker && <img className="map-marker" alt="Map marker" src={mapMarker} />}

        {hasInvoice && <img className={`invoice ${invoiceClassName}`} alt="Invoice" src={invoice} />}

        {hasDonut && <img className={`donut ${donutClassName}`} alt="Donut" src={donut} />}
      </div>
      <div className="texts">
        <div className={`title ${titleClassName}`}>{text}</div>
        <p className="body">{text1}</p>
      </div>
    </div>
  );
};

ServiceElements.propTypes = {
  hasMenu: PropTypes.bool,
  mapMarker: PropTypes.string,
  hasInvoice: PropTypes.bool,
  donut: PropTypes.string,
  group: PropTypes.string,
  hasMapMarker: PropTypes.bool,
  hasDonut: PropTypes.bool,
  text: PropTypes.string,
  text1: PropTypes.string,
  hasMenuWrapper: PropTypes.bool,
  invoice: PropTypes.string,
};
