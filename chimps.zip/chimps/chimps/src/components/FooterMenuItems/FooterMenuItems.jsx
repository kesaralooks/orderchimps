import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const FooterMenuItems = ({
  className,
  text = "Company",
  text1 = "About us",
  text2 = "Team",
  text3 = "Careers",
  hasElement = true,
  text4 = "Blog",
}) => {
  return (
    <div className={`footer-menu-items ${className}`}>
      <div className="title-2">{text}</div>
      <div className="items">
        <div className="element-3">{text1}</div>
        <div className="element-4">{text2}</div>
        <div className="element-4">{text3}</div>
        {hasElement && <div className="element-4">{text4}</div>}
      </div>
    </div>
  );
};

FooterMenuItems.propTypes = {
  text: PropTypes.string,
  text1: PropTypes.string,
  text2: PropTypes.string,
  text3: PropTypes.string,
  hasElement: PropTypes.bool,
  text4: PropTypes.string,
};
