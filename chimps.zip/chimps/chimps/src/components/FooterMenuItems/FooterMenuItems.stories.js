import { FooterMenuItems } from ".";

export default {
  title: "Components/FooterMenuItems",
  component: FooterMenuItems,
};

export const Default = {
  args: {
    className: {},
    text: "Company",
    text1: "About us",
    text2: "Team",
    text3: "Careers",
    hasElement: true,
    text4: "Blog",
  },
};
