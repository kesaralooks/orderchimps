import PropTypes from "prop-types";
import React from "react";
import "./style.css";

export const Badge = ({ property1, className }) => {
  return (
    <div className={`badge ${property1} ${className}`}>
      <div className="text">
        {property1 === "open-now" && <>Open Now</>}

        {property1 === "opens-tomorrow" && <>Opens tomorrow</>}
      </div>
    </div>
  );
};

Badge.propTypes = {
  property1: PropTypes.oneOf(["opens-tomorrow", "open-now"]),
};
