import { Badge } from ".";

export default {
  title: "Components/Badge",
  component: Badge,
  argTypes: {
    property1: {
      options: ["opens-tomorrow", "open-now"],
      control: { type: "select" },
    },
  },
};

export const Default = {
  args: {
    property1: "opens-tomorrow",
    className: {},
  },
};