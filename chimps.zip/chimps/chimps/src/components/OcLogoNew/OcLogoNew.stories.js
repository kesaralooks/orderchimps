import { OcLogoNew } from ".";

export default {
  title: "Components/OcLogoNew",
  component: OcLogoNew,
};

export const Default = {
  args: {
    className: {},
  },
};
