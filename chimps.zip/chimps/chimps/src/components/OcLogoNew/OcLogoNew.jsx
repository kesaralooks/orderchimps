import React from "react";
import "./style.css";

export const OcLogoNew = ({ className }) => {
  return (
    <div className={`oc-logo-new ${className}`}>
      <img className="clip-path-group" alt="Clip path group" />
    </div>
  );
};
