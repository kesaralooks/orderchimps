export { OcLogoNew } from "./OcLogoNew";
